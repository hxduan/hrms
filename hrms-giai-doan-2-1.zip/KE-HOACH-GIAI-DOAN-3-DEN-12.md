# Kế hoạch Giai đoạn 3 → 12 (bản chốt sau Giai đoạn 2.1)

> Tài liệu này **thay thế** mọi lộ trình cũ (các file `lo-trinh-*`, `bo-sung-*`, `build-lai-*`…). Từ đây chỉ cần giữ: file này, `README-GIAI-DOAN-2.md`, `README-GIAI-DOAN-2-1.md`, thư mục `backend/db` và bộ Postman.
> Mỗi giai đoạn kết thúc bằng một **cổng kiểm tra**: bạn chạy bộ test + gửi ảnh chụp, tôi mới viết giai đoạn kế tiếp.

---

## A. Trả lời nhanh 4 câu hỏi của bạn

### A1. Đăng ký / tạo tài khoản / quên mật khẩu / đặt lại mật khẩu theo vai trò (RBAC) — có bỏ được không?

**Bỏ được, và nên bỏ phần công khai.** Điểm mấu chốt: trang đăng ký và quên mật khẩu nằm *trước khi đăng nhập*, tức là hệ thống **chưa biết người dùng là ai** nên không thể phân quyền cho chúng. Muốn "chỉ admin/HR thấy" thì chỉ có một cách: **chuyển chức năng vào bên trong hệ thống**, sau đăng nhập.

| Chức năng | Trước (G2) | Sau (G2.1) | Ai thấy |
|---|---|---|---|
| Đăng ký công khai | Trang `/dang-ky` | **Đã gỡ** (route + trang) | — |
| Tạo tài khoản | Quản trị → Tài khoản | Giữ; tạo bằng **mật khẩu tạm**, buộc đổi ở lần đăng nhập đầu | admin, HR |
| Quên mật khẩu | Trang công khai | **Đã gỡ**; thay bằng nút *Gửi liên kết đặt lại mật khẩu (email)* | admin, HR |
| Đặt mật khẩu tạm | "Đặt lại mật khẩu" | Đổi tên; người dùng bị đăng xuất khỏi mọi thiết bị và buộc đổi mật khẩu | admin, HR |
| Trang `/dat-lai-mat-khau?ma=…` | Công khai | **Vẫn công khai** (bắt buộc: người nhận email chưa đăng nhập), nhưng chỉ dùng được khi có mã hợp lệ do admin/HR phát sinh (băm SHA-256, 30 phút) | người giữ mã |
| Đổi mật khẩu của chính mình | Có | Giữ | mọi vai trò |
| Khóa / mở khóa tài khoản | Chưa có | **Mới** (khi nhân viên nghỉ việc) | admin, HR |
| Đổi vai trò | Có | Giữ | chỉ admin |

**Cái giá bạn phải biết:** gỡ "quên mật khẩu" nghĩa là mỗi lần nhân viên quên mật khẩu thì phải nhờ HR. Và nếu **quản trị viên cuối cùng** quên mật khẩu thì không ai cứu được qua giao diện → tôi thêm `scripts/datLaiAdmin.js` (chạy trên máy chủ). HR cũng không được động vào tài khoản admin/HR khác.

**Còn một lỗ hổng chưa đóng:** đăng nhập Google hiện vẫn **tự tạo** tài khoản chưa gắn hồ sơ (vô hại về dữ liệu vì bị chặn bởi `CHUA_GAN_HO_SO`, nhưng làm rác danh sách). Cách đóng đúng: Google chỉ cho vào khi **email Google trùng email tài khoản đã cấp**. Cần sửa `config/passport.js` — file này bạn có test riêng (`googleProfile.test.js`) mà tôi chưa nhìn thấy. **Gửi tôi hai file đó** là tôi sửa khớp (xem quyết định D7).

### A2. Bỏ ảnh đại diện / Cloudinary
Đồng ý, bỏ hẳn: giao diện dùng chữ cái đầu của tên làm avatar (đã có ở thanh trên). Việc cần làm: chạy migration 003 (gỡ cột `NhanVien.AnhDaiDienUrl`), `pnpm remove cloudinary multer-storage-cloudinary` (**giữ `multer`** — cần cho import Excel ở Giai đoạn 11), xóa 3 biến `CLOUDINARY_*` trong `.env`. Kế hoạch Giai đoạn 3 không còn mục upload ảnh.

### A3. Có nên thêm hoạch định nhân sự? — **Có, nhưng ở dạng nhỏ và có duyệt**
Hiện tại *Định biên* là con số **được duyệt**, nhưng ai có quyền HR đều **sửa thẳng** được con số đó — tức "được duyệt" chỉ là cái tên. Hoạch định chính là quy trình làm cho con số ấy có thật:

| | Định biên (đã có) | Hoạch định (đề xuất thêm — Giai đoạn 5) |
|---|---|---|
| Là gì | Con số trần *hiện hành* theo (phòng ban, chức danh, năm) | **Kế hoạch năm**: đề xuất tăng/giảm, lý do, trình duyệt |
| Ai làm | Sinh ra từ kế hoạch đã duyệt | HR lập & gửi; admin duyệt/từ chối |
| Trả lời câu hỏi | "Được phép có bao nhiêu người?" | "Vì sao đổi? Ai duyệt? Thiếu/thừa bao nhiêu?" |

Phạm vi: **không** làm tuyển dụng (bạn đã loại). Đầu ra chỉ là *báo cáo thiếu/thừa* (định biên − đang giữ + sắp rời đi vì hết hạn hợp đồng/đã báo nghỉ). Khi kế hoạch được duyệt, hệ thống tự cập nhật bảng `DinhBienViTri` trong một transaction và HR **mất quyền sửa thẳng** (xem D1). Bonus: bộ máy "gửi duyệt → duyệt/từ chối có lý do" viết ở đây sẽ được **tái dùng nguyên** cho Đơn từ (G8) và Lương (G10) — nên đây là bài tập khởi động rẻ nhất cho workflow duyệt.

### A4. Công–Lương gộp một khung đang gánh quá nhiều use case — xử lý thế nào?
Đúng, đang gộp **4 mối quan tâm khác nhau** với người dùng, vòng đời và rủi ro khác nhau. Tôi tách thành **3 nhóm menu + 1 đường ống một chiều có 2 cổng chặn** (xem hình ở trên và mục B).

---

## B. Công–Lương: tách như thế nào

### B1. Menu sau khi tách

| Menu (admin / HR) | Menu (nhân viên) | Giai đoạn |
|---|---|---|
| Tổ chức | Tổ chức (chỉ xem) | 2 ✔ |
| Nhân sự | Hồ sơ của tôi | 3–4 |
| **Chấm công** (thiết lập, dữ liệu, bảng công, kỳ công) | Chấm công của tôi | 6–7 |
| **Đơn từ** (hộp duyệt) | Đơn của tôi | 8 |
| **Bảo hiểm & Thuế** (tham số luật, biến động, báo cáo) | — | 9 |
| **Lương** (kỳ lương, bảng lương, duyệt, điều chỉnh) | Phiếu lương của tôi | 10 |
| Báo cáo | — | 11 |
| Quản trị | — | 2 ✔ |

### B2. Đường ống & cổng chặn (mỗi bước chỉ đọc kết quả *đã chốt* của bước trước)

```
Nhân sự (hợp đồng, phụ cấp, người phụ thuộc, ngày vào/nghỉ)
        │ (đầu vào, đọc theo thời điểm hiệu lực)
Chấm công thô ─▶ Công theo ngày ─▶ Công tháng ─▶ ⛔ KHÓA KỲ CÔNG
   ▲                  ▲                                 │ chỉ khi: không còn đơn từ chờ duyệt,
   │                  └── Đơn từ đã duyệt               │ mọi nhân viên đang làm việc đều có công
Máy / nhập tay / import                                  ▼
                                      Tính bảo hiểm ─▶ Tính thuế ─▶ Lương nháp ─▶ ⛔ DUYỆT ─▶ Trả ─▶ Phiếu lương
                                                                                       │
                                                         Sau duyệt chỉ sửa được qua DieuChinhLuong (giải trình + duyệt lại)
```

Quy tắc xuyên suốt: **không tính lương trên kỳ công chưa khóa; không mở khóa kỳ công nếu đã có lương `da_duyet`/`da_tra`; không sửa lương đã duyệt trực tiếp.**

### B3. Bản đồ use case (để bạn dùng làm số liệu cho đề cương — đếm lại khi xong)

| Nhóm | Use case |
|---|---|
| Thiết lập chấm công (G6) | UC-01 Quản lý ca làm việc · UC-02 Phân ca (hàng loạt) · UC-03 Quản lý ngày lễ · UC-04 Xem công chuẩn tháng · UC-05 Cấu hình quy tắc tính công |
| Chấm công (G7) | UC-06 Ghi lượt quẹt thủ công có lý do · UC-07 Import dữ liệu máy chấm công · UC-08 Tổng hợp công ngày/kỳ · UC-09 Xem bảng công tháng · UC-10 Điều chỉnh công tay (có lý do, chỉ khi kỳ mở) · UC-11 Khóa kỳ công · UC-12 Mở khóa kỳ công (admin, có lý do) · UC-13 Xem công của tôi |
| Đơn từ (G8) | UC-14 Tạo đơn nghỉ phép · UC-15 Tạo đơn làm thêm giờ · UC-16 Tạo đơn công tác · UC-17 Hủy đơn đang chờ · UC-18 Duyệt/từ chối (đơn lẻ & hàng loạt) · UC-19 Thu hồi đơn đã duyệt (kỳ còn mở) · UC-20 Xem số dư phép |
| Bảo hiểm & Thuế (G9) | UC-21 Quản lý tham số pháp luật theo hiệu lực · UC-22 Xem gợi ý biến động tăng/giảm · UC-23 Xác nhận biến động BHXH · UC-24 Tính bảo hiểm kỳ (xem trước) · UC-25 Báo cáo BHXH |
| Lương (G10) | UC-26 Xem trước lương · UC-27 Tính lương (hàng loạt) · UC-28 Xem chi tiết & giải trình · UC-29 Gửi duyệt · UC-30 Duyệt / từ chối · UC-31 Đánh dấu đã trả · UC-32 Đề xuất điều chỉnh · UC-33 Duyệt điều chỉnh · UC-34 Xem phiếu lương của tôi |
| **Tổng nhóm Công–Lương** | **34 use case** |

### B4. Ma trận phân quyền chốt (áp dụng khi viết từng giai đoạn)

| Chức năng | admin | hr | nhân viên |
|---|---|---|---|
| Xem sơ đồ tổ chức, chức vụ, chức danh, định biên | ✔ | ✔ | ✔ (đã gắn hồ sơ) |
| Sửa tổ chức / danh mục | ✔ | ✔ | ✖ |
| Lập kế hoạch định biên (đề xuất) | ✔ | ✔ | ✖ |
| **Duyệt** kế hoạch định biên | ✔ | ✖ | ✖ |
| Xem hồ sơ / sửa hồ sơ nhân viên | ✔ | ✔ | chỉ xem hồ sơ **của mình** |
| Hợp đồng, phụ cấp, người phụ thuộc | ✔ | ✔ | chỉ xem của mình |
| Tạo / khóa tài khoản, gửi liên kết, mật khẩu tạm | ✔ | ✔ (chỉ tài khoản nhân viên) | ✖ |
| Đổi vai trò | ✔ | ✖ | ✖ |
| Nhập / điều chỉnh công tay | ✔ | ✔ | ✖ |
| Khóa kỳ công | ✔ | ✔ | ✖ |
| **Mở khóa** kỳ công | ✔ | ✖ | ✖ |
| Tạo đơn từ | ✔ | ✔ | ✔ (chỉ cho chính mình) |
| Duyệt đơn từ | ✔ | ✔ | ✖ (xem D2) |
| Thiết lập tham số pháp luật (BHXH, thuế, lương cơ sở) | ✔ | ✖ | ✖ |
| Tính lương (xem trước / nháp) | ✔ | ✔ | ✖ |
| **Duyệt lương**, đánh dấu đã trả, duyệt điều chỉnh | ✔ | ✖ | ✖ |
| Xem bảng lương mọi người | ✔ | ✔ (xem D3) | ✖ |
| Xem phiếu lương | ✔ | ✔ | chỉ **của mình** và chỉ khi đã `da_duyet` |
| Xem nhật ký thay đổi | ✔ | ✔ | ✖ |

Nguyên tắc cứng (mọi giai đoạn): quyền **do backend kiểm tra**, giao diện chỉ ẩn/hiện; với nhân viên, "của mình" luôn lấy từ `TaiKhoan.NhanVienId` trong DB, **không bao giờ** nhận id từ URL/body.

---

## C. Phát hiện cần sửa trong thiết kế hiện tại (sửa ở giai đoạn ghi bên phải)

Tôi rà lại toàn bộ thiết kế theo yêu cầu "độ chính xác dữ liệu". Có hai phát hiện đến từ việc **đối chiếu thông tin hiện hành** (không thể suy ra từ tài liệu cũ), còn lại là lỗi thiết kế của chính tôi.

| # | Vấn đề | Hậu quả nếu bỏ qua | Sửa ở |
|---|---|---|---|
| C1 | **Địa chỉ 2 cấp.** Thiết kế cũ là Tỉnh → Quận/Huyện. Từ 01/07/2025 mô hình chính quyền địa phương còn **2 cấp (tỉnh/thành → phường/xã), không còn cấp huyện** | Người dùng không chọn được địa chỉ hiện hành | G3 |
| C2 | **BHXH không có trần/sàn và gộp 10,5% trên một cơ sở.** Thực tế BHXH+BHYT có **trần = 20 × lương cơ sở**, còn BHTN có **trần = 20 × lương tối thiểu vùng** → hai cơ sở khác nhau; và **lương cơ sở đổi giữa năm** (2,34 → 2,53 triệu từ 01/07/2026) | Nhân viên lương cao bị trừ BHXH **vượt trần**; sai khi đổi kỳ | G9 |
| C3 | **Công tính theo loại ca, không theo giờ làm.** `sp_TongHopCongNgay` cho `HeSoCong = 1.0` nếu ca cả ngày, dù người đó chỉ làm 2 giờ | Lương sai | G6–G7 |
| C4 | **Khóa công bằng cờ `DaKhoa` trên từng dòng ngày.** Có thể khóa dở dang, không có "ai khóa/khi nào" | Công khóa không nhất quán | G7 (`KyCong`) |
| C5 | **Công chuẩn nhập tay.** Dễ lệch lịch/ngày lễ | Sai mẫu số của công thức lương | G6 |
| C6 | **Sinh mã `NV0001` bằng `SELECT TOP 1 … ORDER BY`.** Hai người tạo cùng lúc → trùng mã | Trùng/lỗi mã | G3 (`SEQUENCE`) |
| C7 | **`SoCCCD UNIQUE` tính cả bản ghi đã xóa mềm.** Tạo nhầm rồi xóa → không nhập lại được CCCD đó | Kẹt dữ liệu | G3 (chỉ mục duy nhất có lọc) |
| C8 | **Hợp đồng chồng lấn thời gian** không bị chặn; **`LoaiHopDong` không có cờ đóng BHXH / cách tính thuế** (thử việc, hợp đồng ngắn hạn xử lý khác) | Tính lương sai cho thử việc | G4 |
| C9 | **Nghỉ việc không khóa tài khoản.** | Người đã nghỉ vẫn đăng nhập được | G4 |
| C10 | **Phụ cấp chỉ có cờ `TinhThue` 0/1.** Thực tế có khoản **miễn thuế đến một mức** (VD tiền ăn) | Thuế sai | G4/G10 |
| C11 | **`NhanVien` chưa có `Email`, `SoSoBHXH`, `MaSoThue`, `NgayVaoLam`, `VungLuong`.** | Không gửi được phiếu lương, không lập được báo cáo BHXH, không tính lương tháng vào làm giữa tháng | G3 |
| C12 | **Ca qua đêm** (kết thúc sau 0h) chưa xử lý; `sp_TongHopCongNgay` chỉ nhìn trong một ngày dương lịch | Công ca đêm sai | **Chưa hỗ trợ** — ghi rõ ở G6, chặn tạo ca qua đêm (D4) |
| C13 | **Ngày lễ trong công chuẩn.** Cần chọn một quy tắc *nhất quán cho cả tử số lẫn mẫu số* | Lệch vài phần trăm lương | G6 (D6) |

> Nguồn đối chiếu cho C1, C2 và các tham số ở mục G9: thuvienphapluat.vn (lương cơ sở 2,53 triệu từ 01/07/2026; trần/sàn đóng BHXH; biểu thuế 5 bậc), amis.misa.vn (mức lương đóng BHXH 2026), provinces.open-api.vn và tài liệu GHN (địa chỉ sau sáp nhập). **Bạn nên để kế toán/chuyên viên nhân sự đối chiếu lần cuối** trước khi dùng số liệu cho báo cáo chính thức.

---

## D. Quyết định cần bạn chốt (mỗi mục có mặc định — không trả lời thì tôi làm theo mặc định)

| # | Câu hỏi | Mặc định |
|---|---|---|
| D1 | Sau khi có hoạch định, HR **mất quyền sửa thẳng** định biên (chỉ admin sửa khẩn cấp, có lý do)? | **Có** |
| D2 | Duyệt đơn từ do ai? (a) HR/admin; (b) thêm cấp **trưởng phòng** duyệt trước (cần `NhanVien.QuanLyTrucTiepId`) | **(a)** |
| D3 | HR có xem được lương của mọi người? (hoặc thêm vai trò `ke_toan`) | **HR xem được**, không thêm vai trò |
| D4 | Ca qua đêm | **Chưa hỗ trợ**, ghi rõ giới hạn |
| D5 | Địa chỉ: gọi API công khai từ trình duyệt hay qua backend có lưu đệm? | **Qua backend, lưu đệm 24 giờ** (demo không phụ thuộc mạng) |
| D6 | Công chuẩn: T2–T6 hay T2–T7; ngày lễ tính vào công chuẩn? | **T2–T6, ngày lễ rơi vào ngày làm việc được hưởng lương và tính vào cả công chuẩn lẫn công hưởng lương** |
| D7 | Google chỉ cho tài khoản đã cấp (khớp email)? | **Có** — cần bạn gửi `passport.js` + `googleProfile.test.js` |
| D8 | Làm tròn tiền | **Đến đồng; thuế làm tròn một lần ở bước cuối** |

---

## E. Vòng làm việc của mỗi giai đoạn
1. Tôi gửi gói zip (chỉ file mới/thay thế) + README giai đoạn.
2. Bạn: chạy migration → chép file → `pnpm test` → chạy **toàn bộ** bộ Postman (hồi quy: mọi giai đoạn trước vẫn phải xanh) → kiểm tra giao diện theo danh sách.
3. Bạn gửi: ảnh Postman Runner, ảnh các màn hình mới, ảnh Diagram CSDL (nếu có bảng mới), lỗi nếu có.
4. Đạt → giai đoạn kế. Không đạt → sửa trước.
Tích hợp được kiểm tra **rải đều**: mỗi giai đoạn thêm một thư mục vào bộ Postman và chạy lại toàn bộ; Giai đoạn 12 chỉ còn kịch bản xuyên suốt chứ không dồn việc.

---

## F. Các giai đoạn

> **Về các chỗ ghi `<tên …>` trong SQL bên dưới:** đó là ràng buộc CHECK/DEFAULT/UNIQUE không đặt tên trong `schema.sql` nên SQL Server tự sinh tên. Migration thật sẽ tra tên động bằng `sys.check_constraints` / `sys.default_constraints` / `sys.key_constraints` rồi mới gỡ. Các khối SQL trong tài liệu này là **bản thiết kế**; bản chạy thật sẽ được viết và kiểm tra ở đầu mỗi giai đoạn.

### Giai đoạn 2.1 — Phân quyền luồng tài khoản + bỏ ảnh đại diện *(đã giao)*
Xem `README-GIAI-DOAN-2-1.md`.

---

### Giai đoạn 3 — Nhân sự: Hồ sơ nhân viên
**Mục tiêu:** danh sách (phân trang, lọc, sắp xếp phía máy chủ) + trang chi tiết có tab + thêm/sửa/xóa mềm + tự sinh mã + kiểm tra định biên + gắn tài khoản; nhân viên xem hồ sơ của mình.
**Phụ thuộc:** G2 (phòng ban, chức vụ, chức danh, định biên).

**CSDL — migration 004**
```sql
CREATE SEQUENCE SeqMaNhanVien AS INT START WITH 1 INCREMENT BY 1;      -- C6: sinh mã an toàn khi tạo đồng thời
EXEC sp_rename 'NhanVien.QuanHuyen', 'PhuongXa', 'COLUMN';               -- C1
ALTER TABLE NhanVien ADD MaTinh NVARCHAR(10) NULL, MaPhuongXa NVARCHAR(10) NULL,
  Email NVARCHAR(255) NULL, NgayVaoLam DATE NULL, SoSoBHXH NVARCHAR(15) NULL,
  MaSoThue NVARCHAR(15) NULL, VungLuong TINYINT NOT NULL CONSTRAINT DF_NV_Vung DEFAULT 1,
  CONSTRAINT CK_NV_Vung CHECK (VungLuong BETWEEN 1 AND 4);
ALTER TABLE NhanVien DROP CONSTRAINT <tên UQ của SoCCCD>;               -- C7
CREATE UNIQUE INDEX UX_NV_CCCD  ON NhanVien (SoCCCD)   WHERE DaXoa = 0 AND SoCCCD IS NOT NULL;
CREATE UNIQUE INDEX UX_NV_Email ON NhanVien (Email)    WHERE DaXoa = 0 AND Email IS NOT NULL;
CREATE UNIQUE INDEX UX_NV_BHXH  ON NhanVien (SoSoBHXH) WHERE DaXoa = 0 AND SoSoBHXH IS NOT NULL;
```
Procedure: `sp_DanhSachNhanVien(@Tim, @PhongBanId, @ChucDanhId, @TrangThai, @SapXep, @Trang, @SoDong)` trả `OFFSET/FETCH` kèm tổng số dòng.

**API**
| Method | Path | admin | hr | nhân viên | Ghi chú |
|---|---|---|---|---|---|
| GET | `/nhan-vien?tim&phongBanId&chucDanhId&trangThai&sapXep&trang&soDong` | ✔ | ✔ | ✖ | phân trang phía máy chủ |
| GET | `/nhan-vien/toi` | ✔ | ✔ | ✔ | hồ sơ của chính mình |
| GET | `/nhan-vien/:id` | ✔ | ✔ | ✖ | `sp_LayThongTinTongQuanNhanVien` |
| POST | `/nhan-vien` | ✔ | ✔ | ✖ | sinh `MaNhanVien`; gọi `kiemTraConDinhBien` |
| PUT | `/nhan-vien/:id` | ✔ | ✔ | ✖ | ghi nhật ký từng cột |
| DELETE · POST `/xoa-nhieu` | ✔ | ✔ | ✖ | chặn nếu còn hợp đồng hiệu lực |
| GET | `/nhan-vien/kiem-tra?truong=CCCD|Email|SoSoBHXH&giaTri&boQuaId` | ✔ | ✔ | ✖ | kiểm tra trùng khi rời ô |
| POST | `/nhan-vien/kiem-tra-dinh-bien` | ✔ | ✔ | ✖ | trả `{ duocPhep, canhBao }` |
| GET | `/dia-chi/tinh` · `/dia-chi/phuong-xa?maTinh=` | ✔ | ✔ | ✖ | proxy + lưu đệm 24 giờ (D5) |

**Màn hình:** `/nhan-su` (bảng + bộ lọc), `/nhan-su/them` và `/nhan-su/:id/sua` (trang riêng vì nhiều trường), `/nhan-su/:id` (tab *Tổng quan* — các tab sau thêm dần ở G4, G9), `/ho-so-cua-toi` (chỉ xem).
**Quy tắc:** CCCD 12 số; SĐT di động VN; MST 10 hoặc 13 số; số sổ BHXH 10 số; tuổi ≥ 15 tại ngày vào làm; nếu hết định biên → cảnh báo, HR bấm "Vẫn tạo" và **lý do vượt định biên được ghi nhật ký**; chọn Tỉnh trước, Phường/Xã lọc theo tỉnh. *Việc đầu tiên của giai đoạn:* mở tài liệu `provinces.open-api.vn` để xác nhận đường dẫn phiên bản mới trước khi viết code gọi.
**Cổng kiểm tra:** tạo 2 nhân viên đồng thời không trùng mã · tạo → xóa → tạo lại cùng CCCD được · nhân viên `nv01` chỉ xem được hồ sơ mình, đổi `id` trên URL vẫn không xem được người khác.

---

### Giai đoạn 4 — Nhân sự: Hợp đồng, quá trình công tác, nghỉ việc, thu nhập & người phụ thuộc
**Mục tiêu:** hoàn thiện "hồ sơ" để các giai đoạn lương có đủ đầu vào.

**CSDL — migration 005**
```sql
ALTER TABLE LoaiHopDong ADD CoDongBaoHiem BIT NOT NULL DEFAULT 1,
                            KieuTinhThue NVARCHAR(12) NOT NULL DEFAULT 'luy_tien'
                            CHECK (KieuTinhThue IN ('luy_tien','khau_tru_10'));      -- C8
ALTER TABLE HopDong ADD SoHopDong NVARCHAR(50) NULL, LuongDongBHXH DECIMAL(18,2) NULL,
                        GhiChu NVARCHAR(300) NULL, DaXoa BIT NOT NULL DEFAULT 0,
  CONSTRAINT CK_HD_Ngay CHECK (NgayKetThuc IS NULL OR NgayKetThuc >= NgayBatDau),
  CONSTRAINT CK_HD_Luong CHECK (LuongCoBan > 0);
ALTER TABLE QuaTrinhLamViec ADD ChucDanhId INT NULL REFERENCES ChucDanh(Id),
  LoaiBienDong NVARCHAR(15) NOT NULL DEFAULT 'dieu_chuyen'
  CHECK (LoaiBienDong IN ('bo_nhiem','dieu_chuyen','thang_chuc','giang_chuc','khac')), SoQuyetDinh NVARCHAR(50) NULL;
ALTER TABLE NghiViec ADD NgayLamViecCuoi DATE NULL;
ALTER TABLE PhuCapNhanVien ADD MienThueToiDa DECIMAL(18,2) NULL;                    -- C10: NULL = không miễn, số = miễn đến mức này
ALTER TABLE NguoiPhuThuocNhanVien ADD QuanHe NVARCHAR(50) NULL, NgaySinh DATE NULL, MaSoThue NVARCHAR(15) NULL, SoCCCD NVARCHAR(20) NULL;
```
Procedures: `sp_DongBoViTriHienTai(@NhanVienId)` (đặt `NhanVien.PhongBanId/ChucVuId/ChucDanhId` = bản ghi quá trình có `NgayHieuLuc ≤ hôm nay` mới nhất; gọi sau mọi thay đổi và mỗi giờ), `sp_HopDongSapHetHan(@SoNgay)`.

**API (tóm tắt, tất cả admin/hr trừ ghi chú):** `/nhan-vien/:id/hop-dong` (GET·POST·PUT·DELETE), `/nhan-vien/:id/qua-trinh` (GET·POST), `/nhan-vien/:id/nghi-viec` (POST·DELETE-hủy quyết định, có lý do), `/nhan-vien/:id/phu-cap`, `/nhan-vien/:id/nguoi-phu-thuoc` (GET·POST·PUT·DELETE); `GET /hop-dong/sap-het-han?soNgay=30`. Nhân viên chỉ `GET` các mục của mình qua `/nhan-vien/toi/...`.
**Màn hình:** các tab *Hợp đồng · Quá trình công tác · Thu nhập & phụ cấp · Người phụ thuộc · Nghỉ việc* trong `/nhan-su/:id`; thẻ "Hợp đồng sắp hết hạn" ở trang chủ HR.
**Quy tắc:** hợp đồng **không chồng lấn** (kiểm tra trong transaction, trả hợp đồng xung đột); chức vụ/chức danh mới → `kiemTraConDinhBien`; ngày hiệu lực ở tương lai thì chưa đổi `NhanVien` cho tới ngày đó; **nghỉ việc → `DangLamViec = 0`, hỏi để khóa tài khoản** (gọi lại `PUT /tai-khoan/:id/trang-thai`), ghi `NgayLamViecCuoi`; phụ cấp không chồng cùng tên cùng kỳ.
**Cổng kiểm tra:** tạo hợp đồng chồng lấn bị chặn · điều chuyển có hiệu lực ngày mai chưa đổi phòng ban hôm nay · nghỉ việc → tài khoản bị khóa, đăng nhập bị từ chối.

---

### Giai đoạn 5 — Hoạch định nhân sự *(khuyến nghị; bỏ qua được nếu D1 = không)*
**CSDL — migration 006**
```sql
CREATE TABLE KeHoachNhanSu (
  Id INT IDENTITY PRIMARY KEY, Nam INT NOT NULL CHECK (Nam BETWEEN 2000 AND 2100), TieuDe NVARCHAR(200) NOT NULL,
  TrangThai NVARCHAR(12) NOT NULL DEFAULT 'nhap' CHECK (TrangThai IN ('nhap','cho_duyet','da_duyet','tu_choi')),
  NguoiTaoId INT NOT NULL REFERENCES TaiKhoan(Id), NguoiDuyetId INT NULL REFERENCES TaiKhoan(Id),
  ThoiGianTao DATETIME NOT NULL DEFAULT GETDATE(), ThoiGianDuyet DATETIME NULL, LyDoTuChoi NVARCHAR(MAX) NULL, GhiChu NVARCHAR(500) NULL);
CREATE UNIQUE INDEX UX_KeHoach_NamDangMo ON KeHoachNhanSu (Nam) WHERE TrangThai IN ('nhap','cho_duyet');
CREATE TABLE KeHoachNhanSu_ChiTiet (
  Id INT IDENTITY PRIMARY KEY, KeHoachId INT NOT NULL REFERENCES KeHoachNhanSu(Id),
  PhongBanId INT NOT NULL REFERENCES PhongBan(Id), ChucDanhId INT NOT NULL REFERENCES ChucDanh(Id),
  SoLuongHienCo INT NOT NULL,                       -- ảnh chụp lúc lập kế hoạch
  SoLuongDinhBienCu INT NOT NULL, SoLuongDeXuat INT NOT NULL CHECK (SoLuongDeXuat >= 0),
  LyDo NVARCHAR(500) NULL, CONSTRAINT UQ_KHCT UNIQUE (KeHoachId, PhongBanId, ChucDanhId));
```
`sp_DuBaoNhanSu(@Nam)`: định biên − đang giữ + (hợp đồng hết hạn trong năm + nghỉ việc đã báo) → cột *Thiếu/Thừa dự kiến*.
**Quy trình duyệt dùng chung** `services/quyTrinhDuyet.js`: `chuyenTrangThai(bang, id, tuCacTrangThai, den, nguoi, lyDo?)` — **một chỗ duy nhất** định nghĩa chuyển trạng thái hợp lệ, dùng lại ở G8 và G10.
**API:** `GET/POST /ke-hoach-nhan-su`, `PUT /:id` (chỉ khi `nhap`), `POST /:id/chi-tiet`, `PUT /:id/gui-duyet` (hr), `PUT /:id/duyet` · `/tu-choi` (admin; từ chối **bắt buộc lý do**), `GET /ke-hoach-nhan-su/du-bao?nam=`.
**Khi duyệt:** trong một transaction → `MERGE` vào `DinhBienViTri` → ghi nhật ký từng dòng → khóa kế hoạch. Từ lúc này `POST/PUT /dinh-bien` của HR trả 403 (nếu D1 = có).
**Màn hình:** `/to-chuc/hoach-dinh` (danh sách kế hoạch, trình soạn dạng bảng có so sánh *hiện có / định biên cũ / đề xuất / chênh lệch*), thẻ *Thiếu/Thừa dự kiến* ở trang Định biên.
**Cổng kiểm tra:** HR gửi → admin từ chối thiếu lý do bị chặn → duyệt → định biên đổi đúng + có nhật ký; HR sửa thẳng định biên bị 403.

---

### Giai đoạn 6 — Chấm công 1: thiết lập
**CSDL — migration 007**
```sql
-- Ca: số giờ chuẩn TỰ TÍNH, thêm dung sai; chặn ca qua đêm (C12)
ALTER TABLE CaLamViec ADD PhutChoPhepDiMuon INT NOT NULL DEFAULT 0, PhutChoPhepVeSom INT NOT NULL DEFAULT 0,
  SoGioChuan AS (CAST(DATEDIFF(MINUTE, GioBatDau, GioKetThuc) - ISNULL(DATEDIFF(MINUTE, GioNghiTruaBatDau, GioNghiTruaKetThuc), 0) AS DECIMAL(6,2)) / 60.0) PERSISTED,
  CONSTRAINT CK_Ca_KhongQuaDem CHECK (GioKetThuc > GioBatDau);
CREATE TABLE CauHinhCong (                       -- hiệu lực theo ngày
  Id INT IDENTITY PRIMARY KEY, NgayHieuLuc DATE NOT NULL UNIQUE,
  LamThuBay BIT NOT NULL DEFAULT 0, LamChuNhat BIT NOT NULL DEFAULT 0,
  NguongMotCong DECIMAL(4,2) NOT NULL DEFAULT 0.90,   -- làm ≥ 90% giờ chuẩn của ca = 1 công
  NguongNuaCong DECIMAL(4,2) NOT NULL DEFAULT 0.45);  -- ≥ 45% = 0.5 công, dưới = 0
ALTER TABLE PhanCa ADD CONSTRAINT UQ_PhanCa UNIQUE (NhanVienId, NgayHieuLuc);
ALTER TABLE NgayLe ADD CONSTRAINT UQ_NgayLe UNIQUE (Ngay);
```
Hàm `fn_CongChuanThang(@Thang, @Nam)`: đếm ngày làm việc theo `CauHinhCong` (**tính cả ngày lễ rơi vào ngày làm việc**, D6); nếu có dòng trong `CongChuanThang` thì dòng đó **ghi đè** (có lý do).
**API:** `/ca-lam-viec` CRUD · `/phan-ca` (GET theo nhân viên/phòng ban, POST **hàng loạt** theo phòng ban + ngày hiệu lực) · `/ngay-le` CRUD + `POST /ngay-le/sao-chep-nam` · `/cau-hinh-cong` · `GET /cong-chuan?thang&nam` (trả giá trị tính toán, ghi đè nếu có).
**Màn hình:** `/cham-cong/thiet-lap` với 4 tab *Ca làm việc · Phân ca · Ngày lễ · Công chuẩn & quy tắc*.
**Ngày lễ:** **không** tự điền từ trí nhớ — bạn nhập theo thông báo nghỉ lễ chính thức của năm; có nút sao chép từ năm trước để sửa.
**Cổng kiểm tra:** tạo ca qua đêm bị chặn · công chuẩn 2026 khớp lịch (bạn tự đếm) · thêm ngày lễ làm công chuẩn không đổi nhưng ngày đó được đánh dấu lễ.

---

### Giai đoạn 7 — Chấm công 2: ghi nhận công, công tháng, kỳ công
**CSDL — migration 008**
```sql
ALTER TABLE ChamCongTho ADD Nguon NVARCHAR(10) NOT NULL DEFAULT 'may' CHECK (Nguon IN ('may','nhap_tay','import')),
  NguoiNhapId INT NULL REFERENCES TaiKhoan(Id), LyDo NVARCHAR(300) NULL;
CREATE TABLE KyCong (                                      -- C4
  Id INT IDENTITY PRIMARY KEY, Nam INT NOT NULL, Thang INT NOT NULL CHECK (Thang BETWEEN 1 AND 12),
  TrangThai NVARCHAR(8) NOT NULL DEFAULT 'mo' CHECK (TrangThai IN ('mo','da_khoa')),
  NguoiKhoaId INT NULL REFERENCES TaiKhoan(Id), ThoiGianKhoa DATETIME NULL, LyDoMoKhoa NVARCHAR(300) NULL,
  CONSTRAINT UQ_KyCong UNIQUE (Nam, Thang));
-- BangCongTongHop: bỏ DaKhoa (gỡ ràng buộc DEFAULT không tên của nó trước), mở rộng trạng thái, lưu ảnh chụp ca
ALTER TABLE BangCongTongHop DROP CONSTRAINT <CK TrangThaiCong>;  ALTER TABLE BangCongTongHop DROP COLUMN DaKhoa;
ALTER TABLE BangCongTongHop ADD CaLamViecId INT NULL REFERENCES CaLamViec(Id), SoGioChuan DECIMAL(6,2) NULL,
  DiMuonPhut INT NOT NULL DEFAULT 0, VeSomPhut INT NOT NULL DEFAULT 0, SoGioLamThem DECIMAL(5,2) NOT NULL DEFAULT 0,
  DieuChinhTay BIT NOT NULL DEFAULT 0, GhiChu NVARCHAR(300) NULL,
  CONSTRAINT CK_TTCong CHECK (TrangThaiCong IN ('di_lam','nghi_phep_luong','nghi_phep_khong_luong','nghi_le','cong_tac','nghi_tuan','vang_khong_phep','chua_vao_lam','da_nghi_viec'));
```
**Quy tắc tính công ngày (sửa C3):** `giờ thực tế = (quẹt muộn nhất − quẹt sớm nhất) − nghỉ trưa nếu bao trùm`; `tỉ lệ = giờ thực tế / SoGioChuan của ca`; `công = 1` nếu ≥ `NguongMotCong`, `0.5` nếu ≥ `NguongNuaCong`, ngược lại `0`; đi muộn/về sớm = phút ngoài dung sai. Ngày nghỉ tuần theo `CauHinhCong`; ngày lễ rơi vào ngày làm việc → `nghi_le`, công = 1; ngày trước `NgayVaoLam` → `chua_vao_lam`, sau ngày nghỉ việc → `da_nghi_viec` (không tính vào công hưởng lương → lương tháng vào/nghỉ giữa kỳ tự đúng).
Thủ tục: `sp_TongHopCongKy(@Nam,@Thang,@PhongBanId)` viết theo **tập hợp** (nhân viên × ngày, không dùng con trỏ), `sp_LayBangCongThang`, `sp_TongCongThang` (công thực làm, công hưởng lương, phép, không lương, muộn, OT).
**API:** `POST /cham-cong/quet-the` (nhập tay, bắt buộc `lyDo`), `POST /cham-cong/import?cheDo=kiemTra|thucThi`, `POST /cham-cong/tong-hop {nam,thang,phongBanId?}`, `GET /bang-cong?thang&nam&phongBanId`, `PUT /bang-cong/:id` (điều chỉnh tay, bắt buộc lý do, **chỉ khi kỳ mở**), `GET /bang-cong/toi?thang&nam`, `GET /ky-cong`, `POST /ky-cong/:nam/:thang/khoa`, `POST /ky-cong/:nam/:thang/mo` (admin, lý do).
**Khóa kỳ công chỉ thành công khi:** (1) không còn đơn từ `cho_duyet` có ngày trong kỳ, (2) mọi nhân viên đang làm việc đều có đủ dòng công cho cả kỳ — nếu không, trả **danh sách cụ thể** vướng ở đâu.
**Màn hình:** `/cham-cong/du-lieu`, `/cham-cong/bang-cong` (lưới nhân viên × ngày có ký hiệu màu, bấm ô để xem/sửa), `/cham-cong/ky-cong`, `/cham-cong/cua-toi` (nhân viên).
**Ký hiệu hiển thị:** `X` đi làm · `½` nửa công · `P` phép hưởng lương · `K` nghỉ không lương · `L` lễ · `CT` công tác · `V` vắng không phép · `-` nghỉ tuần.
**Cổng kiểm tra:** 4 lượt quẹt/ngày ra đúng giờ & công · làm 2 giờ ra 0 công · sửa tay sau khi khóa bị chặn · khóa khi còn đơn chờ duyệt bị chặn kèm danh sách · nhân viên vào làm giữa tháng không bị tính công những ngày trước đó.

---

### Giai đoạn 8 — Đơn từ
**CSDL — migration 009:** mở rộng `DonNghiPhep` (`LoaiNghiPhep` ∈ `phep_nam, khong_luong, om_dau, thai_san, viec_rieng_huong_luong`, cờ `HuongLuong`), `DonLamThemGio` (**`GioBatDau`, `GioKetThuc`** thay vì chỉ số giờ; loại ngày tự suy ra thường/nghỉ/lễ), cả ba bảng thêm `NguoiTaoId`, `ThoiGianDuyet`, `LyDoTuChoi`, `LyDo`; tùy chọn bảng `QuyPhepNam(NhanVienId, Nam, SoNgayDuocHuong, SoNgayDaDung)` (12 ngày/năm, tỉ lệ theo tháng vào làm).
**Quy trình:** `nhap → cho_duyet → da_duyet | tu_choi`, nhân viên hủy được khi `cho_duyet`. **Duyệt xong → áp ngay vào `BangCongTongHop`** (nếu kỳ đã khóa thì **không cho duyệt**, báo rõ); thu hồi đơn đã duyệt chỉ khi kỳ còn mở; gửi email thông báo (Gmail).
**Ràng buộc:** không chồng ngày với đơn khác của cùng người; phép năm không vượt số dư; OT cảnh báo vượt 40 giờ/tháng (xác nhận lại giới hạn với văn bản hiện hành).
**API:** `/don-nghi-phep`, `/don-lam-them-gio`, `/don-cong-tac` (mỗi loại: `GET` của mình hoặc toàn bộ, `POST`, `PUT /:id/huy`), `PUT /:id/duyet`, `PUT /:id/tu-choi`, `POST /don-tu/duyet-nhieu`, `GET /don-tu/cho-duyet`.
**Màn hình:** `/don-tu/cua-toi` (3 tab, tạo & theo dõi), `/don-tu/cho-duyet` (HR/admin: bảng có chọn nhiều → duyệt hàng loạt).
**Cổng kiểm tra:** duyệt đơn nghỉ → bảng công đúng ký hiệu `P` · duyệt đơn trong kỳ đã khóa bị chặn · nhân viên không tạo/xem được đơn của người khác.

---

### Giai đoạn 9 — Bảo hiểm & Thuế
**CSDL — migration 010**
```sql
ALTER TABLE ThamSoLuongTheoNam ADD
  LuongCoSo DECIMAL(18,2) NULL, LuongToiThieuVung1 DECIMAL(18,2) NULL, LuongToiThieuVung2 DECIMAL(18,2) NULL,
  LuongToiThieuVung3 DECIMAL(18,2) NULL, LuongToiThieuVung4 DECIMAL(18,2) NULL,
  SoLanTranBHXH INT NOT NULL DEFAULT 20, SoLanTranBHTN INT NOT NULL DEFAULT 20,
  TyLeBHXH_NLD DECIMAL(5,2) NULL, TyLeBHYT_NLD DECIMAL(5,2) NULL, TyLeBHTN_NLD DECIMAL(5,2) NULL,
  TyLeBHXH_DN DECIMAL(5,2) NULL, TyLeBHYT_DN DECIMAL(5,2) NULL, TyLeBHTN_DN DECIMAL(5,2) NULL, TyLeBHTNLDBNN_DN DECIMAL(5,2) NULL,
  HeSoLamThemThuong DECIMAL(3,2) NULL, HeSoLamThemNghi DECIMAL(3,2) NULL, HeSoLamThemLe DECIMAL(3,2) NULL,
  NgayNghiKhongLuongKhongDongBH INT NOT NULL DEFAULT 14;
-- (sau khi nhập dữ liệu: đặt các cột NULL thành NOT NULL và bỏ cột TyLeBHXH 10,5 gộp cũ)
CREATE TABLE BienDongBaoHiem (
  Id INT IDENTITY PRIMARY KEY, NhanVienId INT NOT NULL REFERENCES NhanVien(Id), Nam INT NOT NULL, Thang INT NOT NULL,
  LoaiBienDong NVARCHAR(20) NOT NULL CHECK (LoaiBienDong IN ('tang_moi','giam','dieu_chinh_luong','ngung_dong','dong_lai')),
  MucLuongDong DECIMAL(18,2) NULL, NgayHieuLuc DATE NOT NULL, LyDo NVARCHAR(300) NULL,
  TrangThai NVARCHAR(14) NOT NULL DEFAULT 'du_kien' CHECK (TrangThai IN ('du_kien','da_ghi_nhan','da_bao_cao')),
  NguoiXacNhanId INT NULL REFERENCES TaiKhoan(Id));
CREATE TABLE BaoHiemKy (                                    -- kết quả tính theo kỳ, để báo cáo & đối chiếu với lương
  Id INT IDENTITY PRIMARY KEY, NhanVienId INT NOT NULL REFERENCES NhanVien(Id), Nam INT NOT NULL, Thang INT NOT NULL,
  LuongDongBHXH DECIMAL(18,2) NOT NULL, LuongDongBHTN DECIMAL(18,2) NOT NULL,
  BHXH_NLD DECIMAL(18,2) NOT NULL, BHYT_NLD DECIMAL(18,2) NOT NULL, BHTN_NLD DECIMAL(18,2) NOT NULL,
  BHXH_DN DECIMAL(18,2) NOT NULL, BHYT_DN DECIMAL(18,2) NOT NULL, BHTN_DN DECIMAL(18,2) NOT NULL, BHTNLDBNN_DN DECIMAL(18,2) NOT NULL,
  CONSTRAINT UQ_BHKy UNIQUE (NhanVienId, Nam, Thang));
```
**Tham số cần nhập (hiệu lực từ 01/07/2026; đối chiếu lần cuối trước khi dùng):** lương cơ sở 2.530.000 → trần BHXH/BHYT = 20 × = **50.600.000**; lương tối thiểu vùng I–IV **5.310.000 / 4.730.000 / 4.140.000 / 3.700.000** → trần BHTN = 20 × lương tối thiểu vùng; tỉ lệ người lao động **8% + 1,5% + 1% = 10,5%**; người sử dụng lao động **17% + 3% + 1% + 0,5% = 21,5%**; giảm trừ **15.500.000 / 6.200.000**; biểu thuế tháng **≤10tr 5% · 10–30tr 10% · 30–60tr 20% · 60–100tr 30% · >100tr 35%** (bậc 1 và 5 cùng các mức 10%/20% đã đối chiếu nguồn; **ngưỡng bậc 3–4 bạn đối chiếu lại** khi nhập). Mỗi lần luật đổi → **thêm một dòng hiệu lực mới**, không sửa dòng cũ (lương kỳ cũ vẫn tra đúng tham số của kỳ đó).
**Hàm thuần** (đặt ở `services/`, có test vàng, xem mục G): `tinhBaoHiem({ luongDong, vung, tamSo })`, `tinhThue({ thuNhapTinhThue, tamSo })`. Giữ ở Node vì dễ kiểm thử hơn T-SQL.
**Quy tắc:** cơ sở đóng = lương hợp đồng (hoặc `LuongDongBHXH` nếu khác) + phụ cấp tính BH, **không nhân theo số công**; kẹp giữa sàn (`max(tham chiếu, lương tối thiểu vùng)`) và trần; hợp đồng `CoDongBaoHiem = 0` (thử việc…) → bằng 0; nghỉ không lương ≥ 14 ngày làm việc trong tháng → ngừng đóng tháng đó; **gợi ý biến động tự sinh** khi: vào làm có hợp đồng đóng BH (`tang_moi`), nghỉ việc (`giam`), đổi lương hợp đồng (`dieu_chinh_luong`), nghỉ không lương dài (`ngung_dong`) — HR xác nhận thì mới thành `da_ghi_nhan`.
**API:** `/tham-so-phap-luat` (GET theo `?ngay=`, POST thêm hiệu lực — admin), `/bao-hiem/bien-dong` (GET·POST·PUT xác nhận), `GET /bao-hiem/goi-y?thang&nam`, `POST /bao-hiem/tinh-ky` (xem trước/lưu `BaoHiemKy`), `GET /bao-hiem/bao-cao?thang&nam` (tổng NLĐ + DN theo kỳ), tab *Bảo hiểm* trong hồ sơ nhân viên.
**Cổng kiểm tra:** 5 ca test vàng (mục G) khớp đến đồng · đổi lương cơ sở có hiệu lực 01/07 thì kỳ 06 vẫn dùng trần cũ, kỳ 07 dùng trần mới.

---

### Giai đoạn 10 — Lương
**CSDL — migration 011**
```sql
ALTER TABLE DienBienLuong ADD KyCongId INT NULL REFERENCES KyCong(Id), ThamSoId INT NULL REFERENCES ThamSoLuongTheoNam(Id),
  LuongCoBanHD DECIMAL(18,2) NULL, CongChuan DECIMAL(5,2) NULL, CongHuongLuong DECIMAL(5,2) NULL,
  TongThuNhap DECIMAL(18,2) NOT NULL DEFAULT 0, TongKhauTru DECIMAL(18,2) NOT NULL DEFAULT 0,
  NgayTra DATE NULL, HinhThucTra NVARCHAR(30) NULL;
-- Mở rộng các dòng chi tiết để "giải trình" thấy được từng bước tính
ALTER TABLE DienBienLuong_ChiTiet DROP CONSTRAINT <CK LoaiKhoan>;
ALTER TABLE DienBienLuong_ChiTiet ADD GhiChuCongThuc NVARCHAR(300) NULL,
  CONSTRAINT CK_DBL_Loai CHECK (LoaiKhoan IN ('ngay_cong','luong_theo_cong','phu_cap','lam_them','thu_nhap_khac',
    'bhxh','bhyt','bhtn','giam_tru_ban_than','giam_tru_phu_thuoc','thu_nhap_tinh_thue','thue_tncn','khau_tru_khac','dieu_chinh'));
```
**Công thức (mỗi dòng ghi `GhiChuCongThuc` để giải trình):** `lương theo công = lương HĐ ÷ công chuẩn × công hưởng lương` → `+ phụ cấp + làm thêm + thu nhập khác` → `− BHXH − BHYT − BHTN` → `thu nhập tính thuế = thu nhập chịu thuế − bảo hiểm − giảm trừ bản thân − giảm trừ người phụ thuộc − phần phụ cấp miễn thuế` → `thuế theo biểu 5 bậc` → `thực nhận`. Làm thêm giờ: phần *chênh lệch so với giờ thường* được miễn thuế (xác nhận lại với kế toán).
**Cổng vào:** kỳ công `da_khoa`; mỗi nhân viên phải có hợp đồng hiệu lực và tham số pháp luật hiệu lực; nhân viên thiếu → **bỏ qua có lý do cụ thể** chứ không dừng cả lô.
**Vòng đời:** `nhap → cho_duyet → da_duyet → da_tra`, `tu_choi → nhap`; chỉ `nhap/tu_choi` được tính lại; sau `da_duyet` chỉ sửa qua `DieuChinhLuong`; mở khóa kỳ công bị cấm khi có lương `da_duyet/da_tra`.
**API:** `POST /luong/xem-truoc` (không lưu) · `POST /luong/tinh {nam,thang,phongBanId?}` · `GET /luong?thang&nam` · `GET /luong/:id` (`sp_LayChiTietDienBienLuong`) · `PUT /luong/gui-duyet` (cả lô) · `PUT /luong/:id/duyet` · `/tu-choi` · `/danh-dau-da-tra` · `POST /luong/:id/de-xuat-dieu-chinh` · `GET /dieu-chinh-luong` · `PUT …/duyet` · `…/tu-choi` · `GET /luong/cua-toi?thang&nam` (chỉ lương đã duyệt của chính mình).
**Màn hình:** `/luong/ky-luong` (trạng thái từng bước: công đã khóa? bao nhiêu người đã tính? bao nhiêu chờ duyệt?), `/luong/bang-luong`, `/luong/bang-luong/:id` (từng dòng kèm công thức + lịch sử + nút đề xuất điều chỉnh), `/luong/cho-duyet`, `/luong/dieu-chinh`, `/luong/phieu-luong-cua-toi`.
**Cổng kiểm tra:** 5 ca test vàng khớp khi chạy qua **cả API lẫn giao diện** · tính lương khi kỳ chưa khóa bị chặn · nhân viên thiếu hợp đồng bị bỏ qua có lý do · nhân viên **không** xem được lương `nhap`/`cho_duyet` của chính mình · điều chỉnh sau duyệt cần giải trình + duyệt và để lại nhật ký.

---

### Giai đoạn 11 — Import/Export Excel & Báo cáo
**Import** (dùng lại mẫu *tải mẫu → kiểm tra (dry-run) → thực thi*, khớp theo **tiêu đề cột cố định** và theo `MaNhanVien`, `MaPhongBan`, tên chức danh): danh sách nhân viên · dữ liệu chấm công từ máy · khoản thu nhập khác của kỳ lương (dòng `thu_nhap_khac`, nguồn `import_excel`, chỉ khi lương còn `nhap`). Tải file **báo lỗi** theo từng dòng. Giới hạn 5 MB / 5.000 dòng, dùng `multer` (bộ nhớ) + `exceljs`.
**Export:** nhân viên · bảng công tháng · bảng lương · báo cáo BHXH · định biên/hoạch định.
**Dashboard** (Recharts): cơ cấu theo phòng ban, biến động nhân sự theo tháng, hợp đồng sắp hết hạn, chi phí lương theo tháng, định biên so với đang giữ.
**Cổng kiểm tra:** file 150 dòng có 3 dòng lỗi ngày → báo đúng dòng, nhập được 147 dòng sau khi sửa · file sai tiêu đề bị từ chối rõ ràng.

---

### Giai đoạn 12 — Hoàn thiện & nghiệm thu
Kịch bản xuyên suốt chạy bằng Postman Runner (tạo phòng ban → nhân viên → hợp đồng → phân ca → chấm công cả tháng → đơn nghỉ/OT được duyệt → khóa công → tính lương → duyệt → trả → phiếu lương → điều chỉnh), rà soát ma trận phân quyền (mục B4) từng endpoint, đo hiệu năng với **200 nhân viên × 30 ngày** để đặt chỉ mục, kịch bản sao lưu/khôi phục CSDL, README, ERD xuất từ Azure Data Studio, video demo, và bảng số liệu **đếm bằng lệnh** (mục H).

---

## G. Test vàng cho bảo hiểm & thuế (đã tính tay + kiểm bằng mã)
Tham số: hiệu lực 01/07/2026; vùng I; giảm trừ 15.500.000 / 6.200.000; trần BHXH/BHYT 50.600.000; trần BHTN 106.200.000; người lao động 8% / 1,5% / 1%.

| # | Đầu vào | Bảo hiểm (NLĐ) | Thu nhập tính thuế | Thuế TNCN | Thực nhận |
|---|---|---|---|---|---|
| 1 | Lương 20.000.000, 0 người phụ thuộc | 2.100.000 | 2.400.000 | 120.000 | **17.780.000** |
| 2 | 30.000.000, 1 người phụ thuộc | 3.150.000 | 5.150.000 | 257.500 | **26.592.500** |
| 3 | 60.000.000, 2 người phụ thuộc *(vượt trần BHXH/BHYT)* | 4.807.000 + 600.000 = 5.407.000 | 26.693.000 | 2.169.300 | **52.423.700** |
| 4 | 100.000.000, 0 người phụ thuộc *(qua 4 bậc thuế)* | 4.807.000 + 1.000.000 = 5.807.000 | 78.693.000 | 14.107.900 | **80.085.100** |
| 5 | Lương HĐ 22.000.000, công 20/22 *(BH tính theo lương HĐ, không theo công)* | 2.310.000 | 2.190.000 | 109.500 | **17.580.500** (lương theo công 20.000.000) |

Ca 3 và 4 là hai ca bắt lỗi quan trọng nhất: nếu code quên trần BHXH hoặc tách sai cơ sở BHTN, số sẽ lệch ngay.

---

## H. Số liệu hiện có và cách đếm lại (để đề cương luôn khớp thiết kế)

Đã đếm tại thời điểm Giai đoạn 2.1: **28 bảng** · **1 view** · **6 thủ tục/hàm** · **43 endpoint** · **30 test thuần mới** (chưa tính test cũ của bạn) · **88 request Postman** · **10 màn hình thật** (đăng nhập, đặt lại mật khẩu, callback Google, trang chủ, tài khoản của tôi, phòng ban, chức vụ, chức danh, định biên, quản trị tài khoản).

| Giai đoạn | Bảng mới | Endpoint mới (ước lượng) | Màn hình mới (ước lượng) | Test Postman mới (ước lượng) |
|---|---|---|---|---|
| 3 | 0 (+1 sequence) | 12 | 4 | 22 |
| 4 | 0 | 22 | 5 tab | 30 |
| 5 | 2 | 10 | 2 | 16 |
| 6 | 1 | 16 | 1 (4 tab) | 22 |
| 7 | 1 | 14 | 4 | 28 |
| 8 | 0–1 | 16 | 2 | 28 |
| 9 | 2 | 14 | 3 | 22 |
| 10 | 0 | 18 | 6 | 34 |
| 11 | 0 | 12 | 3 | 18 |
| **Dự kiến cuối** | **≈ 34–35 bảng** | **≈ 190 endpoint** | **≈ 45 màn hình** | **≈ 330 request** |

*Đây là ước lượng thiết kế, không phải số đo.* Số thật đếm bằng lệnh sau mỗi giai đoạn (chạy ở thư mục `backend`):
```bash
grep -c "^CREATE TABLE" db/schema.sql                                  # bảng trong schema gốc (cộng thêm CREATE TABLE trong db/migrations/*.sql)
grep -hoE "router\.(get|post|put|delete)\(" src/routes/*.js | wc -l     # endpoint
grep -hE "^\s*(test|it)\(" tests/*.test.js | wc -l                      # test thuần
node -e "let n=0;(function w(i){for(const x of i)x.item?w(x.item):n++})(require('./postman/HRMS-GiaiDoan1-2.postman_collection.json').item);console.log(n)"   # request Postman
```
và trên SQL Server: `SELECT COUNT(*) FROM sys.tables;`

---

## I. Rủi ro lớn nhất (để bạn chủ động)
1. **Giai đoạn 9–10 là nặng nhất** (luật + số tiền). Đã giảm rủi ro bằng: hàm thuần có test vàng, tham số theo hiệu lực, cổng chặn, và việc tách thành các giai đoạn nhỏ chứ không dồn.
2. **Số liệu pháp lý thay đổi.** Hệ thống lưu tham số theo ngày hiệu lực nên đổi luật chỉ là thêm dòng; nhưng *con số trong tài liệu này phải được người có chuyên môn đối chiếu* trước khi dùng cho báo cáo chính thức.
3. **Phụ thuộc bên ngoài:** Gmail SMTP (giới hạn gửi), API địa chỉ công khai (đã có phương án lưu đệm), Google OAuth (đang chờ D7).
