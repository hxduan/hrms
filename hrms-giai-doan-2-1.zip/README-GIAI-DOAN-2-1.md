# Giai đoạn 2.1 — Phân quyền luồng tài khoản + bỏ ảnh đại diện

Bản bổ sung lên trên Giai đoạn 2. Kế hoạch các giai đoạn sau nằm ở `KE-HOACH-GIAI-DOAN-3-DEN-12.md` (đọc mục **A** và **D** trước).

## 1. Thay đổi

| Hạng mục | Trước | Sau |
|---|---|---|
| Tự đăng ký công khai | Có (`/dang-ky`, `POST /auth/tu-dang-ky`) | **Đã gỡ** (trả 404) |
| Quên mật khẩu công khai | Có (`/quen-mat-khau`, `POST /auth/quen-mat-khau`) | **Đã gỡ** (trả 404) |
| Đặt lại mật khẩu | Do người dùng tự yêu cầu | Chỉ qua **liên kết admin/HR gửi** từ Quản trị → Tài khoản (mã băm SHA-256, 30 phút) |
| Tạo tài khoản / đặt lại mật khẩu bởi admin/HR | Mật khẩu thường | **Mật khẩu tạm** → người dùng bị **buộc đổi** ở lần đăng nhập đầu (giao diện *và* backend đều chặn) |
| Khóa tài khoản | Chưa có | **Khóa / mở khóa** (nhân viên nghỉ việc); khóa thì thu hồi mọi phiên |
| `GET /auth/kiem-tra-ten` | Công khai | Chỉ admin/HR (không cho người lạ dò tên đăng nhập) |
| Quản trị viên cuối cùng quên mật khẩu | Không có lối thoát | `node scripts/datLaiAdmin.js <tên> <mật-khẩu-mới>` |
| Ảnh đại diện / Cloudinary | Trong kế hoạch | **Bỏ** (cột `AnhDaiDienUrl` bị gỡ) |

Quyền cho các thao tác trên tài khoản: xem mục **B4** của file kế hoạch. Tóm tắt: admin làm được tất cả; HR làm được trên tài khoản **nhân viên** (không động vào admin/HR khác, không đổi vai trò); nhân viên chỉ đổi mật khẩu của chính mình.

## 2. Danh sách file

**GHI ĐÈ** (nếu bạn đã sửa các file này, hãy so sánh trước):
- `backend/src/middleware/auth.js` · `backend/src/routes/auth.js` · `backend/src/routes/taiKhoan.js` · `backend/src/validation/taiKhoan.js`
- `backend/tests/taiKhoanValidation.test.js` · `backend/.env.example` · `backend/postman/HRMS-GiaiDoan1-2.postman_collection.json`
- `frontend/src/App.jsx` · `auth/RequireAuth.jsx` · `layouts/AppLayout.jsx` · `components/Icon.jsx` · `pages/DangNhap/DangNhap.jsx` · `pages/TaiKhoan/TaiKhoanCuaToi.jsx` · `pages/QuanTri/TaiKhoan.jsx`

**MỚI:** `backend/db/migrations/003_giai_doan_2_1.sql` · `backend/scripts/datLaiAdmin.js` · `backend/src/services/batDoiMatKhau.js` · `backend/src/services/khoiPhucMatKhau.js` · `backend/tests/batDoiMatKhau.test.js`

**XÓA:** `frontend/src/pages/DangNhap/DangKy.jsx` · `frontend/src/pages/DangNhap/QuenMatKhau.jsx`

## 3. Quy trình thực hiện

| # | Việc | Công cụ | Kiểm tra xong bước này |
|---|---|---|---|
| 1 | **Chạy migration `003_giai_doan_2_1.sql` TRƯỚC khi khởi động lại backend** (code mới đọc cột `HoatDong`, `BatDoiMatKhau`) | Azure Data Studio / SSMS | In `Migration 003 hoàn tất.`; `TaiKhoan` có `BatDoiMatKhau`, `HoatDong`; `NhanVien` **không còn** `AnhDaiDienUrl` |
| 2 | Chép file, xóa 2 file ở mục XÓA | VS Code | Không còn import tới `DangKy`/`QuenMatKhau` |
| 3 | Gỡ thư viện không dùng: `pnpm remove cloudinary multer-storage-cloudinary` (**giữ `multer`**, Giai đoạn 11 cần). Xóa 3 dòng `CLOUDINARY_*` trong `.env`. Có thể xóa `CHO_PHEP_TU_DANG_KY` | Terminal | `pnpm install` không lỗi |
| 4 | Build lại frontend (`pnpm build`) rồi chạy lại backend | Terminal | Trang đăng nhập **không còn** liên kết "Quên mật khẩu" / "Tạo tài khoản" |
| 5 | `pnpm test` | Terminal | Xanh (thêm 2 file test mới, không cần DB) |
| 6 | Nhập lại bộ Postman (88 request) → Run collection theo thứ tự thư mục 00 → 03. *Tùy chọn:* đặt biến `emailGoc` thành email Gmail của bạn (dạng `ten@gmail.com`) để nhận thử email đặt lại | Postman | Tất cả xanh (trừ ghi chú bên dưới) |
| 7 | Kiểm tra thủ công (mục 4) | Trình duyệt | Đạt đủ |

**Ghi chú Postman:** request *"Admin gửi liên kết đặt lại mật khẩu qua email"* chấp nhận **200** (Gmail đã cấu hình) hoặc **502** (chưa cấu hình, kèm hướng dẫn) — đó là chủ ý, vì tôi không thể biết máy bạn đã cấu hình Gmail chưa. Nếu muốn nhận email thật: điền `GMAIL_USER`, `GMAIL_APP_PASSWORD` trong `.env`. Nếu gặp **429** khi chạy lại nhiều lần: đợi 15 phút hoặc đặt `GIOI_HAN_DANG_NHAP=20`.

## 4. Kiểm tra thủ công trên giao diện

**Luồng mật khẩu tạm (quan trọng nhất)**
- [ ] Đăng nhập `admin` → Quản trị → Tài khoản → **Tạo tài khoản** (mật khẩu tạm, vai trò nhân viên). Dòng mới có nhãn vàng **"Chờ đổi mật khẩu tạm"**.
- [ ] Mở cửa sổ ẩn danh, đăng nhập bằng tài khoản vừa tạo → **bị đưa thẳng** tới "Tài khoản của tôi", menu bị ẩn, có cảnh báo; gõ tay `/to-chuc` vẫn bị đưa về trang đổi mật khẩu.
- [ ] Nhập sai mật khẩu tạm → báo lỗi ngay dưới ô; nhập đúng + mật khẩu mới hợp lệ → vào được hệ thống, nhãn "Chờ đổi…" biến mất ở phía admin.
- [ ] Nhân viên mới (chưa gắn hồ sơ) vào Tổ chức → thông báo "chưa được gắn hồ sơ".

**Khóa / gửi liên kết / đặt mật khẩu tạm**
- [ ] Khóa tài khoản đó → cửa sổ ẩn danh bị đăng xuất; đăng nhập lại → "Tài khoản đã bị khóa" (khi nhập **sai** mật khẩu chỉ báo "Sai tài khoản hoặc mật khẩu").
- [ ] Mở khóa → đăng nhập lại được.
- [ ] *Gửi liên kết đặt lại mật khẩu (email)*: hộp thoại xác nhận → toast hiển thị địa chỉ **đã che** (`a***@gmail.com`); mở email → bấm liên kết → đặt mật khẩu mới → đăng nhập được; **dùng lại liên kết lần 2 báo hết hạn**.
- [ ] Không tự khóa được mình; không khóa được admin cuối cùng.

**Vai trò**
- [ ] `hr01`: menu Quản trị có, nhưng với tài khoản **admin** thì không có hành động nào (chỉ xem lịch sử); không thấy "Đổi vai trò".
- [ ] `nv01`: không thấy Quản trị; gõ `/quan-tri/tai-khoan` → "Bạn không có quyền".
- [ ] Gõ `/dang-ky` và `/quen-mat-khau` → trang "Không tìm thấy" (sau đăng nhập) hoặc về đăng nhập.

**Cứu hộ:** `node scripts/datLaiAdmin.js admin MatKhauMoi123` → đăng nhập được và bị buộc đổi mật khẩu.

## 5. Tiêu chí đạt để sang Giai đoạn 3
1. Migration 003 chạy xong; `pnpm test` xanh.
2. Bộ Postman 88 request xanh (cho phép 502 ở đúng request gửi email nếu chưa cấu hình Gmail).
3. Đạt đủ mục 4.
4. Bạn trả lời các quyết định **D1–D8** trong file kế hoạch (hoặc nói "theo mặc định") và **gửi `passport.js` + `googleProfile.test.js`** nếu muốn đóng nốt lỗ hổng Google tự tạo tài khoản (D7).

## 6. Giới hạn đã biết
- Đăng nhập Google vẫn tự tạo tài khoản chưa gắn hồ sơ (chờ D7).
- Khóa tài khoản không cắt ngay access token đang sống (tối đa 15 phút), nhưng chặn làm mới và đăng nhập lại.
- Đổi vai trò có hiệu lực tối đa sau 15 phút (quyền nằm trong access token).
- Gửi email phụ thuộc Gmail SMTP (giới hạn ~500 thư/ngày).
